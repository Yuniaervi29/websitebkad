<?php 

class Agenda extends CI_Controller {

	function __construct()
	{
		parent::__construct();

        $this->load->library('Admin');
		$this->load->model('master_model');
		$this->load->model('user_model');
		$this->load->model('agenda_model');

        if($this->session->userdata('status')!='login'){
			redirect(base_url("admin/login"));
		}
	}

	function index()
	{
        $post = $this->agenda_model->get_agenda();
        $output['POST'] = $post['result'];
		$output['PAGE_TITLE'] = 'AGENDA';
		$this->admin->view('admin/agenda', $output);
	}

	function add()
	{
        if (!isset($_POST['title']))
		{
            $output['EDIT'] = array(
                "status" => "add",
                "agenda_id" => "",
                "title" => "",
                "content" => "",
                "file" => "",
                "tgl_agenda" => ""
            );            
		    $this->admin->view('admin/agenda_form', $output);
		}
		else
		{
			$upload_path = 'uploads/agenda/';
			if(substr(sprintf('%o', fileperms($upload_path)), -4) != '0777'){
				chmod($upload_path, 0777);
			}

			if( isset($_FILES['file']['tmp_name']) AND is_uploaded_file($_FILES['file']['tmp_name']) ){
				$filename				= $this->security->sanitize_filename(strtolower($_FILES['file']['name']));
				$filename				= 'download_'.date('ymd_his_').rand(1111,9999).'_'.$filename;
				$data['file']			= $filename;
				$destination			= $upload_path . $filename;
				move_uploaded_file($_FILES['file']['tmp_name'], $destination);
			}

			$uid = $this->session->userdata('id');

			$data['agenda_id']	= '';
			$data['title']			= $this->input->post('title');
			$data['content']			= $this->input->post('content');
			$data['tgl_agenda']			= $this->input->post('tgl_agenda');
			$data['username']		= $uid;
			$this->agenda_model->insert_agenda($data);

			$this->session->set_userdata('message','Data telah tersimpan.');
			$this->session->set_userdata('message_type','success');

			$this->index();
		}
	}

	function edit()
	{
		$id = $this->uri->segment(4);
        if (!isset($_POST['title']))
		{
            $post = $this->agenda_model->get_agenda_by_id($id);
            $output['EDIT'] = array(
                "status" => "edit",
				"agenda_id" => $id,
                "title" => $post->title,
                "content" => $post->content,
                "file" => $post->file,
                "tgl_agenda" => $post->tgl_agenda,
            );            
		    $this->admin->view('admin/agenda_form', $output);
		}
		else
		{
			$upload_path = 'uploads/agenda/';
			if(substr(sprintf('%o', fileperms($upload_path)), -4) != '0777'){
				chmod($upload_path, 0777);
			}

			if( $remove_file = $this->input->post('file') ){
				$data['file'] = '';
				if( file_exists($upload_path.$remove_file) ){
					@unlink($upload_path.$remove_file);
				}
			}

			if( isset($_FILES['file']['tmp_name']) AND is_uploaded_file($_FILES['file']['tmp_name']) ){
				$filename				= $this->security->sanitize_filename(strtolower($_FILES['file']['name']));
				$filename				= 'agenda_'.date('ymd_his_').rand(1111,9999).'_'.$filename;
				$data['file']			= $filename;
				$destination			= $upload_path . $filename;
				move_uploaded_file($_FILES['file']['tmp_name'], $destination);
			}

			$uid = $this->session->userdata('id');

			$data['title']				= $this->input->post('title');
			$data['content']			= $this->input->post('content');
			$data['tgl_agenda']			= $this->input->post('tgl_agenda');
			$data['username']				= $uid;

			$this->agenda_model->update_agenda($data,$id);

			$this->session->set_userdata('message','Data telah tersimpan.');
			$this->session->set_userdata('message_type','success');

			$this->index();
		}
	}

	function delete()
	{
		$id = $this->input->post('agenda_id');

		$query = $this->db->get_where('tb_agenda', array('agenda_id' => $id));
		foreach ($query->result() as $record)
		{
			$file = './uploads/agenda/'.$record->file; 
			if(file_exists($file))
			{
				unlink($file);
			}

			$data=$this->agenda_model->delete_agenda($id);        
			echo json_encode($data);
		}
	}

	
}