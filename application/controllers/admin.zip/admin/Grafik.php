<?php

class Grafik extends CI_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->library('Admin');
		$this->load->model('master_model');
		$this->load->model('user_model');
		$this->load->model('grafik_model');

        if($this->session->userdata('status')!='login'){
			redirect(base_url("admin/login"));
		}
	}

	function index()
	{
        $unit = $this->grafik_model->get_unit();
		$output['UNIT'] =$unit['result'];
		
		$gol = $this->grafik_model->get_gol();
		$output['GOL'] =$gol['result'];
		
		$pend = $this->grafik_model->get_pend();
		$output['PEND'] =$pend['result'];
		
		$jab = $this->grafik_model->get_jab();
		$output['JAB'] =$jab['result'];
		
		$output['PAGE_TITLE'] = 'GRAFIK INFO KEPEGAWAIAN';
		$this->admin->view('admin/info_peg', $output);
	}





	function edit_data()
	{
		$id = $this->input->post('no');
		$data['lk']		= $this->input->post('lk');
		$data['pr']		= $this->input->post('pr');

		$st = $this->input->post('st');
		if ($st=='unit') {
			$result = $this->grafik_model->update_unit($data,$id);
		}else if($st=='gol'){
			$result = $this->grafik_model->update_gol($data,$id);
		}else if($st=='jab'){
			$result = $this->grafik_model->update_jab($data,$id);
		}else if($st=='pend'){
			$result = $this->grafik_model->update_pend($data,$id);
		}
		

		echo json_encode($result);
		
	}

	
}